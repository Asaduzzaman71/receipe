<ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i
          class="fas fa-th-large"></i></a>
    </li>
  </ul>
<?php /**PATH H:\xampp\htdocs\dalorum\resources\views/include/admin/_right_navbar.blade.php ENDPATH**/ ?>