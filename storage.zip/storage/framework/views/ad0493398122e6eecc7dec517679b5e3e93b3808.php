<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">All deal</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Deals</a></li>
                <li class="breadcrumb-item active">All deal</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div>
            <div style="margin:10px 35px">
                <?php echo $__env->make('include.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- form start -->
            <div class="row">
                <div class="col-12">
                  <div class="card">
                    <div class="card-header">
                       <h3 class="card-title">All deals list</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                      <table class="table table-hover text-nowrap">
                        <thead>
                          <tr>
                            <th>ID</th>
                            <th>title</th>
                            <th>Image</th>
                            <th>description</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php if(count($deals)>0): ?>
                            <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($deal->id); ?></td>
                                <td><?php echo e($deal->title); ?></td>
                                <td><img height="50" width="50" src="<?php echo e(asset('storage/'.$deal->image)); ?>"></td>
                                <td><?php echo e($deal->description); ?></td>
                                <td>
                                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('deals.edit', $deal->id)); ?>"><i class="fas fa-edit"></i></a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('deals.destroy', $deal->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>
                      </table>
                    </div>
                    <!-- /.card-body -->
                  </div>
                  <!-- /.card -->
                </div>
              </div>
            </div>
            <!-- /.card -->
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\dalorum\resources\views/deals/index.blade.php ENDPATH**/ ?>