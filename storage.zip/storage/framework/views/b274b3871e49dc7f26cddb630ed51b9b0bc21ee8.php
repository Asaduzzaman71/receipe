<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
            <i class="nav-icon fas fa-handshake"></i>
            <p>
                Deals
                <i class="right fas fa-angle-left"></i>
            </p>
            </a>
            <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="<?php echo e(route('deals.index')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>All deals</p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('deals.create')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Created</p>
                </a>
            </li>

            </ul>
        </li>
        <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
            <i class="nav-icon fas fa-user"></i>
            <p>
                Users
                <i class="right fas fa-angle-left"></i>
            </p>
            </a>
            <ul class="nav nav-treeview">
                <li class="nav-item">
                    <a href="<?php echo e(route('users.index')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>All Users</p>
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<?php /**PATH H:\xampp\htdocs\dalorum\resources\views/include/admin/_sidebar.blade.php ENDPATH**/ ?>